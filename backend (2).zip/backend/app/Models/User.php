<?php
/**
 * User Model
 */

namespace App\Models;

use App\Core\Model;

class User extends Model {
    protected string $table = 'users';

    /**
     * Find user by email
     */
    public function findByEmail(string $email): ?array {
        $sql = "SELECT * FROM {$this->table} WHERE email = ?";
        return $this->db->getOne($sql, [$email]);
    }

    /**
     * Create new user
     */
    public function createUser(array $data): ?array {
        // Hash password
        if (isset($data['password'])) {
            $data['password_hash'] = password_hash($data['password'], PASSWORD_ARGON2ID);
            unset($data['password']);
        }

        // Set default values
        $data['id'] = $data['id'] ?? $this->generateUUID();
        $data['created_at'] = $data['created_at'] ?? date('Y-m-d H:i:s');
        $data['updated_at'] = $data['updated_at'] ?? date('Y-m-d H:i:s');

        return parent::create($data);
    }

    /**
     * Verify password
     */
    public function verifyPassword(string $plainPassword, string $hashedPassword): bool {
        if ($hashedPassword === '') {
            return false;
        }

        $info = password_get_info($hashedPassword);
        if (($info['algoName'] ?? 'unknown') !== 'unknown') {
            return password_verify($plainPassword, $hashedPassword);
        }

        return hash_equals($hashedPassword, $plainPassword);
    }

    /**
     * Generate UUID v4
     */
    public function generateUUID(): string {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }

    /**
     * Get user with profile
     */
    public function getUserWithProfile(string $userId): ?array {
        $user = $this->find($userId);
        if (!$user) {
            return null;
        }

        $sql = "
            SELECT 
                u.*,
                p.first_name,
                p.last_name,
                p.display_name,
                p.avatar_url,
                p.bio,
                p.institution,
                p.research_interests
            FROM {$this->table} u
            LEFT JOIN user_profiles p ON u.id = p.user_id
            WHERE u.id = ?
        ";
        try {
            return $this->db->getOne($sql, [$userId]) ?: $user;
        } catch (\Throwable $e) {
            error_log("User profile join failed: " . $e->getMessage());
        }

        try {
            $sql = "
                SELECT
                    u.*,
                    p.full_name,
                    p.avatar_url,
                    p.bio,
                    p.department,
                    p.phone_number,
                    p.researcher_type,
                    p.is_verified
                FROM {$this->table} u
                LEFT JOIN profiles p ON u.id = p.user_id
                WHERE u.id = ?
            ";
            return $this->db->getOne($sql, [$userId]) ?: $user;
        } catch (\Throwable $e) {
            error_log("Legacy profile join failed: " . $e->getMessage());
        }

        return $user;
    }
}
